''' This script takes a fastq or fasta file in plain format 
	or as a .gz file as input and 
	outputs a fasta file of non redundant sequences ranked by abundance

   Written by Pablo Gutierrez 
   Grupo de Biotecnologia microbiana
   Universidad Nacional de Colombia sede Medellin
   Last modification: 03/03/2020
   Contributors:
   Financed by:
   '''
#============================
# Imports
#============================
import argparse
import os
import re
import sys

#============================
# Arguments
#============================
parser = argparse.ArgumentParser()

parser.add_argument("-query", 
	help = "Path to query")

parser.add_argument("-db", 
	help = "Path to database")

parser.add_argument("-num_threads", 
	help = "number of processors to use during BLAST searches", 
	default=4,
	type=int)

args = parser.parse_args()
num_threads = args.num_threads
query = args.query
db = args.db

#============================
# BLAST parameters
#============================
evalue = "10"
path_to_outputfolder = os.path.dirname(query)
output_files_basename = os.path.basename(query)
BLAST_results = os.path.join(path_to_outputfolder,
	"GenomeBLAST_"+output_files_basename.split(".")[0]+".tsv")

BLAST_command = ("blastn -db "+db 
	+" -max_target_seqs 1 -max_hsps 1 -num_threads "
	+str(num_threads)
	+" -evalue "+evalue
	+" -outfmt \"6 qseqid stitle pident evalue length slen sstart send\" -query "
	+query
	+" -out "+ BLAST_results)

print ("\n=== running: ",
	output_files_basename," against ",os.path.basename(db)," database  ===")
os.system(BLAST_command)
print ("results written as 		:",BLAST_results)

#============================
# Separation of files
#============================
set_of_positives = set()

positive_host_sequences = os.path.join(path_to_outputfolder,
	"HostSequences_" + output_files_basename)
negative_host_sequences = os.path.join(path_to_outputfolder,
	"nonHostSequences_" + output_files_basename)

fileObj = open(BLAST_results)
for line in fileObj:
	sequenceID = line.split("\t")[0]
	set_of_positives.add(sequenceID)
fileObj.close()

# removal of old files
if os.path.exists(positive_host_sequences):
	os.system("rm " + positive_host_sequences)
if os.path.exists(negative_host_sequences):
	os.system("rm " + negative_host_sequences)

flag = str()
fileObj = open(query)

positive_host_sequences_list = list()
negative_host_sequences_list = list()

for line in fileObj:
	if line[0] == ">":		
		title = line[1:-1]
		if title in set_of_positives:
			flag = "positive"
			positive_host_sequences_list.append(">"+title+"\n")
		elif title not in set_of_positives:
			flag = "negative"
			negative_host_sequences_list.append(">"+title+"\n")

	elif line[0] != ">" and flag == "positive":
		positive_host_sequences_list.append(line)
	elif line[0] != ">" and flag == "negative":
		negative_host_sequences_list.append(line)

with open(positive_host_sequences, 'w') as file_handler:
    for item in positive_host_sequences_list:
       file_handler.write("{}".format(item))

with open(negative_host_sequences, 'w') as file_handler:
    for item in negative_host_sequences_list:
       file_handler.write("{}".format(item))

print ("Host sequences saved as 	: "+positive_host_sequences)
print ("Non Host sequences saved as 	: "+negative_host_sequences)
print ("Removing file 			: "+query)
os.system("rm "+query)
	
temporary_file = os.path.join(path_to_outputfolder,"temp.txt")
nr_file = open(temporary_file,"w") 
nr_file.write(negative_host_sequences)
nr_file.close()

#============================
# End of script
#============================



