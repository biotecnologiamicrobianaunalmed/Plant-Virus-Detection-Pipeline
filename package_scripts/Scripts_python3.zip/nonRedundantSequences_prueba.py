
''' This script takes a fastq or fasta file in plain format 
   or as a .gz file as input and 
   outputs a fasta file of non redundant sequences ranked by abundance

   Written by Pablo Gutierrez 
   Grupo de Biotecnologia microbiana
   Universidad Nacional de Colombia sede Medellin
   Last modification: 03/03/2020
   Contributors:
   Financed by:
   '''
#============================
# Imports
#============================
import sys
import gzip
import os
import argparse

#============================
# Functions
#============================
def reverse_complement(sequence):
	'''Converts sequence to reverse complement, 
	including ambiguous nucleotides'''
	complement = str()
	reverse_complementary_sequence = str()
	for nucleotide in sequence:
		if nucleotide == "A":
			complement += "T" 
		elif nucleotide == "C":
			complement += "G" 
		elif nucleotide == "G":
			complement += "C" 
		elif nucleotide == "T":
			complement += "A" 
		elif nucleotide == "N":
			complement += "N" 
		elif nucleotide == "M":
			complement += "K" 
		elif nucleotide == "R":
			complement += "Y" 
		elif nucleotide == "W":
			complement += "W" 
		elif nucleotide == "S":
			complement += "S" 
		elif nucleotide == "Y":
			complement += "R" 
		elif nucleotide == "K":
			complement += "M" 
		elif nucleotide == "V":
			complement += "B" 
		elif nucleotide == "H":
			complement += "D" 
		elif nucleotide == "D":
			complement += "H" 
		elif nucleotide == "B":
			complement += "V" 
		reverse_complementary_sequence = complement[::-1]
	return reverse_complementary_sequence

#============================
# Arguments
#============================
parser = argparse.ArgumentParser()
parser.add_argument("-seq1", 
	required=True, 
	help = "path to sequence file 1 in fastq or fasta format")
parser.add_argument("-seq2", 
	help = "path to sequence file 2 in fastq or fasta format")
parser.add_argument("-output_name", 
	help = "basename of output directory and files", 
	type=str)
parser.add_argument("-subset", 
	help = "use the specified number of reads for analysis", 
	type=int)
parser.add_argument("-remove_bad_reads", 
	help = "do not include reads with ambiguous base calls",
	action="store_true")
parser.add_argument("-top", 
	help = "use only the most abundant non redundant reads for analysis", 
	type=int)
parser.add_argument("-threshold", 
	help = "exclude non redundant reads below the specified sequence count", 
	default=0,
	type=int)

args = parser.parse_args()
sequence_file1 = args.seq1
sequence_file2 = args.seq2
output_name = args.output_name
subset_size = args.subset
remove_bad_reads = args.remove_bad_reads
top_nr = args.top
abundance_treshold = args.threshold

#============================
# Global variables
#============================
sequence_count_dictionary = dict()
sequence_quality_dictionary = dict()
sorted_nonredundant_sequences = list()

gz_format = [".gz"]
fastq_format = [".fastq", ".fq"]
fasta_format = [".fasta", ".fa", ".fna", ".fas"]

file_name_tuples = list()

#============================
# Verification of files
#============================
print ("\n=== Verification of files  ===")

#Define path and output folder name
input_files = list()
output_files_basename = str()
output_folder_name = str()
path_to_outputfolder = str()
path_to_sequences = os.path.dirname(os.path.abspath(args.seq1))


if not output_name and not sequence_file2:
	output_folder_name = ("Results_"
		+os.path.basename(sequence_file1).split(".")[0])	
	path_to_outputfolder = path_to_sequences
	output_files_basename = os.path.basename(sequence_file1).split(".")[0]

elif not output_name and sequence_file2:
	output_folder_name = ("Results_"
		+os.path.basename(sequence_file1).split(".")[0]+"_pe")
	path_to_outputfolder = path_to_sequences
	output_files_basename = os.path.basename(sequence_file1).split(".")[0]
else:
	output_folder_name = ("Results_"
		+os.path.basename(output_name))
	path_to_outputfolder = os.path.dirname(os.path.abspath(output_name))
	output_files_basename = os.path.basename(output_name)

print (output_folder_name)
print (path_to_outputfolder)

if not sequence_file2:
	input_files =[sequence_file1]
else:
	input_files =[sequence_file1,sequence_file2]

for item in input_files:
	basename = os.path.basename(item)
	corename = os.path.splitext(basename)[0]
	file_extension = os.path.splitext(basename)[1]
	compression = False
	print (" Verifying file", basename)
	if file_extension in gz_format:
		print (" ",file_extension, "is an accepted file extension")
		file_extension = "."+corename.split(".")[-1]
		compression = True
	elif file_extension in fastq_format:
		print (" ",file_extension, "is an accepted file extension")
	elif file_extension in fasta_format:
		print (" ",file_extension, "is an accepted file extension")
	else:
		print (" ",file_extension, "is not an accepted file extension")
		sys.exit("\nExecution stopped. Accepted file extensions are: "
			+".gz, .fq, .fastq, .fasta, .fa, .fna or .fas\n")
	file_name_tuples.append((item,corename,file_extension,compression))

#============================
# removal of redundancy
#============================
print ("\n=== Removal of redundant sequences ===")

# Creation of output directory
print (" Creating output directory: ", output_folder_name)
output_directory = os.path.join(path_to_outputfolder,output_folder_name)
create_directory_command = "mkdir "+ output_directory
if not os.path.exists(output_directory):
	os.system(create_directory_command)

if subset_size:
	print (" Subset flag activated, selecting a maximum of ",
		subset_size, " sequences")

# Creation of dictionary of counts
for item in file_name_tuples:
	fileObj = str()
	sequence_file_path = item[0]
	sequence_file_name = item[1]
	sequence_file_format = item[2]
	file_compression = item[3]
	file_format = str()
	print (" Processing file: ",sequence_file_name)

	if sequence_file_format in fastq_format and file_compression == True:
		fileObj = gzip.open(sequence_file_path,'rt')
		file_format = "fastq"
	elif sequence_file_format in fastq_format and file_compression == False:
		fileObj = open(sequence_file_path)
		file_format = "fastq"
	elif sequence_file_format in fasta_format and file_compression == True:
		fileObj = gzip.open(sequence_file_path,'rt')
		file_format = "fasta"
	elif sequence_file_format in fasta_format and file_compression == False:
		fileObj = open(sequence_file_path)
		file_format = "fasta"
	else:
		sys.exit("\nError. Could not process file!\n")

	temp = str()
	number_of_sequences = 0

	# Processing of fastq formats
	if file_format == "fastq":
		sequence_counter = 0
		sequence_flag = str()
		sequence = str()	

		for line in fileObj:

			if subset_size and number_of_sequences >= subset_size:
				break
			line = line.rstrip('\r\n')

			if line[0] == "@" and sequence_counter == 0:
				sequence_flag = "ON"

			elif line[0] == "+" and len(line) == 1:				
				sequence = sequence.upper()
				number_of_sequences += 1
				list_complementary_sequences = ([sequence, 
					reverse_complement(sequence)])
				list_complementary_sequences.sort()
				sequence_key = list_complementary_sequences[0]

				if sequence_key in sequence_count_dictionary:
					sequence_count_dictionary[sequence_key] += 1
				else:
					sequence_count_dictionary[sequence_key] = 1
				sequence = ""	
				sequence_flag = "OFF"

			elif sequence_flag == "ON":
				sequence_counter += len(line)
				sequence += line

			elif sequence_flag == "OFF":
				sequence_counter -= len(line)
		fileObj.close()

	# Processing of fasta formats
	if file_format == "fasta":
		sequence = str()	

		for line in fileObj:
			if subset_size and number_of_sequences >= subset_size:
				break

			line = line.rstrip('\r\n')

			if line[0] == ">":
				if len(sequence) > 0:
					sequence = sequence.upper()
					number_of_sequences += 1					
					list_complementary_sequences = ([sequence,
						reverse_complement(sequence)])
					list_complementary_sequences.sort()
					sequence_key = list_complementary_sequences[0]
					if sequence_key in sequence_count_dictionary:
						sequence_count_dictionary[sequence_key] += 1
					else:
						sequence_count_dictionary[sequence_key] = 1
					sequence = ""	
			else:
				sequence += line

		# Saves last sequence
		if len(sequence) > 0:
			sequence = sequence.upper()
			list_complementary_sequences = ([sequence,
				reverse_complement(sequence)])
			list_complementary_sequences.sort()
			sequence_key = list_complementary_sequences[0]
		if sequence_key in sequence_count_dictionary:
			sequence_count_dictionary[sequence_key] += 1
		else:
			sequence_count_dictionary[sequence_key] = 1

		fileObj.close()

#============================
# Generation of output files
#============================

print ("\n=== Generation of output files ===")

non_redundant_sequence_filename = os.path.join(path_to_outputfolder,
	output_folder_name,output_files_basename+"_nr.fa")
summary_table = os.path.join(path_to_outputfolder,
	output_folder_name,output_files_basename+"_nr_summary.tsv")

print (" Writing file: ", non_redundant_sequence_filename)
print (" Writing file: ", summary_table)

if os.path.exists(non_redundant_sequence_filename) == True:
	os.system("rm "+non_redundant_sequence_filename)
if os.path.exists(summary_table) == True:
	os.system("rm "+summary_table)

sequence_rank = 0
sequence_count = 0
nr_sequences_list = list()

for key, value in sorted(sequence_count_dictionary.items(), 
	key = lambda item: item[1],
	reverse = True):
#	if remove_bad_reads and "N" in key:
#		break

	sequence_rank += 1
	sequence_count += value

	if top_nr and sequence_rank > top_nr:
		break
	if abundance_treshold > value:
		break

	edited_sequence = (">"+str(sequence_rank) 
		+"_"+str(value) 	
		+"\n"+key+"\n")

	nr_sequences_list.append(edited_sequence)


with open(non_redundant_sequence_filename, 'w') as file_handler:
    for item in nr_sequences_list:
       file_handler.write("{}".format(item))


redundancy = round(100-100*sequence_rank/sequence_count,1)
temporary_file = os.path.join(path_to_outputfolder,
	output_folder_name,"temp.txt")

nr_file = open(temporary_file,"w") 
nr_file.write(non_redundant_sequence_filename)
nr_file.close()

print ("\n=== Summary ===")
print (" Total sequences 		:",sequence_count)
print (" Non redundant sequences 	:",sequence_rank)
print (" Redundancy 			:",str(redundancy)+"%")

#============================
# End of script
#============================




