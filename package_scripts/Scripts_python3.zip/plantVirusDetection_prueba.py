''' This script takes a fastq or fasta file in plain format 
   or as a .gz file as input and 
   outputs a fasta file of non redundant sequences ranked by abundance

   Written by Pablo Gutierrez 
   Grupo de Biotecnologia microbiana
   Universidad Nacional de Colombia sede Medellin
   Last modification: 12/03/2020
   Contributors:
   Financed by:
   '''
#============================
# Imports
#============================
import argparse
import sys
import os
import time

#============================
# Arguments
#============================
parser = argparse.ArgumentParser()
parser.add_argument("-seq1", 
	required=True, 
	help = "path to sequence file 1 in fastq or fasta format")
parser.add_argument("-seq2", 
	help = "path to sequence file 2 in fastq or fasta format")
parser.add_argument("-hostdb", 
	help = "path to custom filtering DB or default DBs: Potato, Gulupa or CapeGooseberry")
parser.add_argument("-num_threads", 
	help = "number of processors to use during BLAST searches", 
	default=4,
	type=int)
parser.add_argument("-output_name", 
	help = "basename of output directory and files", 
	type=str)
parser.add_argument("-subset", 
	help = "use the specified number of reads for analysis", 
	type=int)
parser.add_argument("-remove_bad_reads", 
	help = "do not include reads with ambiguous base calls",
	action="store_true")
parser.add_argument("-top", 
	help = "use only the most abundant non redundant reads for analysis", 
	type=int)
parser.add_argument("-threshold", 
	help = "exclude non redundant reads below the specified sequence count", 
	type=int)


args = parser.parse_args()
sequence_file1 = args.seq1
sequence_file2 = args.seq2
hostDB = args.hostdb
num_threads = args.num_threads
output_name = args.output_name
subset_size = args.subset
remove_bad_reads = args.remove_bad_reads
top_nr = args.top
abundance_treshold = args.threshold

#============================
# Global variables
#============================

start_time = time.time()

#Scripts
non_redundant_seq_script = "nonRedundantSequences_prueba.py"
genomeBLAST_script = "hostFilter_prueba.py"
virusBLAST_script = "virusFilter_prueba.py"
outputTables_script = "outputTables_prueba.py"

#Default databases
#virusDB = "PlantVirusesDB"
virusDB = "maskedPlantVirusDBv2"
default_hostDB = {
	"Potato_masked"
	}

#============================
# Paths
#============================
path_to_scripts = os.path.dirname(os.path.abspath(sys.argv[0]))

path_to_databases = os.path.join(
	os.path.split(path_to_scripts)[0],
	"Databases")

path_to_non_redundant_seq_script = os.path.join(
	path_to_scripts,
	non_redundant_seq_script)

path_to_genomeBLAST_script = os.path.join(
	path_to_scripts,
	genomeBLAST_script)

path_to_virusBLAST_script = os.path.join(
	path_to_scripts,
	virusBLAST_script)

path_to_outputTables_script = os.path.join(
	path_to_scripts,
	outputTables_script)


output_folder_name = ""
path_to_sequences = os.path.dirname(os.path.abspath(sequence_file1))


if output_name:
	output_folder_name = "Results_"+os.path.basename(output_name)
	path_to_outputfolder = os.path.dirname(os.path.abspath(output_name))
	output_files_basename = os.path.basename(output_name)

elif sequence_file1 and  not sequence_file2:
	output_folder_name = ("Results_"
		+os.path.basename(sequence_file1).split(".")[0]
		)
	path_to_outputfolder = path_to_sequences
	output_files_basename = os.path.basename(sequence_file1).split(".")[0]

elif sequence_file1 and sequence_file2:
	output_folder_name = ("Results_"
		+os.path.basename(sequence_file1).split(".")[0]+"_pe"
		)
	path_to_outputfolder = path_to_sequences
	output_files_basename = os.path.basename(sequence_file1).split(".")[0]


print ("\n=== Plant Virus Detection Program ===\n")
print ("Execution parameters")
print ("Sequence file 1: 	", sequence_file1)
print ("Sequence file 2: 	", sequence_file2)
print ("Host dababase: 	", hostDB)
print ("Number of processors: 	", num_threads)
print ("Output folder:		", output_name)
print ("Subset size:		", subset_size)
print ("Remove bad reads:	", remove_bad_reads)
print ("Top nr sequences:	", top_nr)
print ("Abundance threshold:	", abundance_treshold)


#================================
# Non-redundant sequences script
#================================
start_compression_time = time.time()

print ("\n=== Step 1: Removal of redundant sequences ===\n")

nr_redundant_sequences_command = str()
if sequence_file2:
	nr_redundant_sequences_command = ("python3 "
		+path_to_non_redundant_seq_script
		+" -seq1 "
		+sequence_file1
		+" -seq2 "
		+sequence_file2
		)
else:
	nr_redundant_sequences_command = ("python3 "
		+path_to_non_redundant_seq_script
		+" -seq1 "
		+sequence_file1
		)
if remove_bad_reads:
	nr_redundant_sequences_command += " -remove_bad_reads "
if output_name:
	nr_redundant_sequences_command += " -output_name "+output_name
if subset_size:
	nr_redundant_sequences_command += " -subset "+str(subset_size)
if abundance_treshold:
	nr_redundant_sequences_command += " -threshold "+str(abundance_treshold)

print (nr_redundant_sequences_command)
os.system(nr_redundant_sequences_command)

time_step_1 = round(time.time()-start_compression_time,3)
print("Execution time of step 1: %s seconds" % (time_step_1))

#================================
# GenomeBLAST
#================================
start_genomeBLAST_time = time.time()

print ("\n=== Step 2: Filtering ===")
genomeBLAST_command = str()

if not hostDB:
	print ("Filtering step was not chosen.\nContinuing with virus detection step.")
elif hostDB in default_hostDB:
	Query_file = os.path.join(path_to_outputfolder,
		output_folder_name,
		"temp.txt")
	nr_file = open(Query_file).readline().rstrip() #file generated by nr_script
	path_to_defaulthostDB = os.path.join(path_to_databases,hostDB)
	print ("non redundant sequence file: ", nr_file)
	print ("filtering database         : ", path_to_defaulthostDB )
	genomeBLAST_command = ("python3 "
		+path_to_genomeBLAST_script
		+" -query "
		+nr_file
		+" -db "
		+path_to_defaulthostDB
		+" -num_threads "
		+str(num_threads)
		)
else:
	Query_file = os.path.join(path_to_outputfolder,
		output_folder_name,
		"temp.txt")
	nr_file = open(Query_file).readline().rstrip() #file generated by nr_script
	print ("non redundant sequence file: ", nr_file)
	print ("filtering database         : ", hostDB )
	genomeBLAST_command = ("python3 "
		+path_to_genomeBLAST_script
		+" -query "
		+nr_file
		+" -db "
		+hostDB
		+" -num_threads "
		+str(num_threads)
	)

os.system(genomeBLAST_command)

time_step_2 = round(time.time()-start_genomeBLAST_time,3)
print("Execution time of step 2: %s seconds" % (time_step_2))

#================================
# VirusBLAST
#================================
start_virusBLAST_time = time.time()

print ("\n=== Step 3: Virus Detection ===")
virusBLAST_command = str()

Query_file = os.path.join(path_to_outputfolder,
	output_folder_name,
	"temp.txt")
nr_file = open(Query_file).readline().rstrip() # this file is generated by nr_script
path_to_virusDB = os.path.join(path_to_databases,virusDB)
print ("Query 	: ", nr_file)
print ("Viral database : ", path_to_virusDB )

virusBLAST_command = ("python3 "
	+path_to_virusBLAST_script
	+" -query "
	+nr_file+" -db "
	+path_to_virusDB
	+" -num_threads "
	+str(num_threads)
	)

os.system(virusBLAST_command)

time_step_3 = round(time.time()-start_virusBLAST_time,3)
print("Execution time of step 3: %s seconds" % (time_step_3))

os.system("rm "+Query_file )
total_execution_time = round(time.time()-start_time,3)
print("Total execution time: %s seconds" % (total_execution_time))

#================================
# Generation of summary table
#================================
start_outputTables_time = time.time()

print ("\n=== Step 4: Generation of summary tables ===")

# Start generation of Summary table
viral_sequences  = ("PutativeViralSequences_"
	+output_files_basename
	+"_nr.fa")
non_identified_sequences = ("nonIdentifiedSequences_"
	+output_files_basename
	+"_nr.fa")
host_sequences = ("HostSequences_"
	+output_files_basename
	+"_nr.fa")

viral_seq_path = os.path.join(path_to_outputfolder,
	output_folder_name,
	viral_sequences)
non_identified_seq_path = os.path.join(path_to_outputfolder,
	output_folder_name,
	non_identified_sequences)
host_seq_path = os.path.join(path_to_outputfolder,
	output_folder_name,
	host_sequences)

nr_viral_seq_count = 0
total_viral_seq_count = 0

nr_non_identified_seq_count = 0
total_non_identified_seq_count = 0

nr_host_seq_count = 0
total_host_seq_count = 0

#print (viral_seq_path)
fileObj = open(viral_seq_path)
for line in fileObj:
	if ">" in line:
		nr_viral_seq_count += 1
		line = line.rstrip('\r\n')
		temp = line.split("_")
		total_viral_seq_count += int(temp[1])
fileObj.close()

fileObj = open(non_identified_seq_path)
for line in fileObj:
	if ">" in line:
		nr_non_identified_seq_count += 1
		line = line.rstrip('\r\n')
		temp = line.split("_")
		total_non_identified_seq_count += int(temp[1])
fileObj.close()

if os.path.exists(host_seq_path) == True:
	fileObj = open(host_seq_path)
	for line in fileObj:
		if ">" in line:
			nr_host_seq_count += 1
			line = line.rstrip('\r\n')
			temp = line.split("_")
			total_host_seq_count += int(temp[1])
	fileObj.close()		

total_sequences = (total_viral_seq_count
	+total_non_identified_seq_count
	+total_host_seq_count)

print ("Putative viral sequences: "
	+str(total_viral_seq_count)
	+"("+str(round(100*total_viral_seq_count/total_sequences,2))+"%)")

print ("Non identified sequences: "
	+str(total_non_identified_seq_count)
	+"("+str(round(100*total_non_identified_seq_count/total_sequences,2))+"%)")

print ("Putative host sequences: "
	+str(total_host_seq_count)+
	"("+str(round(100*total_host_seq_count/total_sequences,2))+"%)")

summary_table = list()
summary_table.append("class\ttotal_count\tpercent")

summary_table.append("viral\t"
	+str(total_viral_seq_count)+"\t"
	+str(round(100*total_viral_seq_count/total_sequences,2)))

summary_table.append("non_identified\t"
	+str(total_non_identified_seq_count)+"\t"
	+str(round(100*total_non_identified_seq_count/total_sequences,2)))

summary_table.append("host\t"
	+str(total_host_seq_count)+"\t"
	+str(round(100*total_host_seq_count/total_sequences,2)))

output_table_name = os.path.join(path_to_outputfolder,
	output_folder_name,
	"SummaryTable_"+output_files_basename+".tsv")

with open(output_table_name, 'w') as file_handler:
    for item in summary_table:
       file_handler.write("{}\n".format(item))


#================================
# Virus filtering
#================================
start_outputTables_time = time.time()

path_to_summary_table = os.path.join(path_to_outputfolder,
		output_folder_name,
		output_table_name)

virusBLAST_file = os.path.join(path_to_outputfolder,
	output_folder_name,
	"BLASTresults.txt")
path_to_virusBLAST_results = open(virusBLAST_file).readline().rstrip() # this file is generated by nr_script


print ("\n=== Step 5: Ouput Tables ===")

outputTables_command = ("python3 "+path_to_outputTables_script
	+" -summary_table "+path_to_summary_table
	+" -results_virusBLAST "+path_to_virusBLAST_results 
	)

print (outputTables_command)
os.system(outputTables_command)

print("Total execution time: %s seconds" % (total_execution_time))

#============================
# End of script
#============================
