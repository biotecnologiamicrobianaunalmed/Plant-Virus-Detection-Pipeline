''' This script takes a fastq or fasta file in plain format 
	or as a .gz file as input and 
	outputs a fasta file of non redundant sequences ranked by abundance

	Written by Pablo Gutierrez 
	Grupo de Biotecnologia microbiana
	Universidad Nacional de Colombia sede Medellin
	Last modification: 28/02/2020'''

#============================
# Imports
#============================
import argparse
import re
import sys
import os

#============================
# Arguments
#============================
parser = argparse.ArgumentParser()
parser.add_argument("-query", 
	help = "Path to query")

parser.add_argument("-db", 
	help = "Path to database")

parser.add_argument("-num_threads", 
	help = "number of processors to use during BLAST searches", 
	default=4,
	type=int)

parser.add_argument("-false_positive_filter", 
	help = "uses custom filtering_db", 
	action="store_true")

args = parser.parse_args()
num_threads = args.num_threads
query = args.query
db = args.db
false_positive_filter = args.false_positive_filter

#============================
# BLAST parameters
#============================
evalue = "1e-5"
task = "dc-megablast"
template_type = "coding_and_optimal"
template_length = str(21)
false_positive_db = os.path.join(os.path.dirname(db),"false_positives")

path_to_outputfolder = os.path.dirname(query)
output_files_basename = os.path.basename(query)
BLAST_results = os.path.join(path_to_outputfolder,
	"virusBLAST_"+output_files_basename.split(".")[0]+".tsv")

BLAST_command = ("blastn -db "+db
		+" -max_target_seqs 1 -max_hsps 1 -num_threads "
		+str(num_threads)
		+" -outfmt \"6 qseqid stitle pident evalue length slen sstart send\" -query "
		+query
		+" -task "+task
		+" -evalue "+evalue
		+" -template_type "+template_type
		+" -template_length "+template_length
		+" -out "+ BLAST_results)

if false_positive_filter:
	BLAST_command += " -false_positive_filter "+false_positive_db

print ("\n=== running: ",
	output_files_basename," against ", os.path.basename(db)," database  ===")
os.system(BLAST_command)
print ("results written as 		:", BLAST_results)

#============================
# Separation of files
#============================
set_of_positives = set()

corrected_based_name = output_files_basename.replace("nonHostSequences_","")

positive_host_sequences = os.path.join(path_to_outputfolder,
	"PutativeViralSequences_" + corrected_based_name)
negative_host_sequences = os.path.join(path_to_outputfolder,
	"nonIdentifiedSequences_" + corrected_based_name)

fileObj = open(BLAST_results)
for line in fileObj:
	sequenceID = line.split("\t")[0]
	set_of_positives.add(sequenceID)
fileObj.close()

# removal of old files
if os.path.exists(positive_host_sequences):
	os.system("rm " + positive_host_sequences)
if os.path.exists(negative_host_sequences):
	os.system("rm " + negative_host_sequences)

flag = str()
fileObj = open(query)

positive_host_sequences_list = list()
negative_host_sequences_list = list()

for line in fileObj:
	if line[0] == ">":		
		title = line[1:-1]
		if title in set_of_positives:
			flag = "positive"
			positive_host_sequences_list.append(">"+title+"\n")
		elif title not in set_of_positives:
			flag = "negative"
			negative_host_sequences_list.append(">"+title+"\n")

	elif line[0] != ">" and flag == "positive":
		positive_host_sequences_list.append(line)
	elif line[0] != ">" and flag == "negative":
		negative_host_sequences_list.append(line)

with open(positive_host_sequences, 'w') as file_handler:
    for item in positive_host_sequences_list:
       file_handler.write("{}".format(item))

with open(negative_host_sequences, 'w') as file_handler:
    for item in negative_host_sequences_list:
       file_handler.write("{}".format(item))

print ("Host sequences saved as 	: "+positive_host_sequences)
print ("Non Host sequences saved as 	: "+negative_host_sequences)
print ("Removing file 			: "+query)
os.system("rm "+query)

temporary_file = os.path.join(path_to_outputfolder
	,"BLASTresults.txt")
nr_file = open(temporary_file,"w") 
nr_file.write(BLAST_results)
nr_file.close()
	

#============================
# End of script
#============================

