''' This script takes a fastq or fasta file in plain format 
	or as a .gz file as input and 
	outputs a fasta file of non redundant sequences ranked by abundance

	Written by Pablo Gutierrez 
	Grupo de Biotecnologia microbiana
	Universidad Nacional de Colombia sede Medellin
	Last modification: 28/02/2020'''

#============================
# Imports
#============================
import argparse
import sys
import os
import math
import statistics
from statistics import mean
from statistics import stdev
from statistics import median


#============================
# Functions
#============================

def diversity(histogram):
	diversity = 0
	total_count = sum(histogram)
	for element in histogram:
		if element > 0:
			frequency = int(element)/int(total_count)
			diversity -= frequency*math.log(frequency)
	diversity = round(diversity,2)
	return(diversity)

def evenness(histogram):
	evenness = round(diversity(histogram)/math.log(100),2)
	return(evenness)

def sum_of_residuals(histogram):
	sum_of_residuals = 0
	squared_sum_of_residuals = 0
	cummulative_sum = 0

	for i in range(0,100):
		cummulative_sum += 100*histogram[i]/sum(histogram)
		sum_of_residuals += cummulative_sum-i+1
		squared_sum_of_residuals += (cummulative_sum-i+1)**2
	
	root_squared_sum_of_residuals = round(math.sqrt(squared_sum_of_residuals/100),2)
	average_sum_of_residuals = round(sum_of_residuals/100,2)
	return(average_sum_of_residuals,root_squared_sum_of_residuals)

#============================
# Arguments
#============================
parser = argparse.ArgumentParser()
parser.add_argument("-summary_table", 
	required=True, 
	help = "Path to summary table")
parser.add_argument("-results_virusBLAST", 
	required=True, 
	help = "Path to virusBLAST results")
parser.add_argument("-species_demarcation", 
	type = float,
	default=95.0,
	help = "Pident threshold for species demarcation")
parser.add_argument("-RPM", 
	default=1,
	type = float,
	help = "Minimum RPM for selection of positives")
parser.add_argument("-counts", 
	default=1,
	type = int,
	help = "Minimum number of hits for selection of positives")
parser.add_argument("-evenness", 
	default=0.8,
	type = int,
	help = "Minimum number of hits for selection of positives")


args = parser.parse_args()
summary_table = args.summary_table
results_virusBLAST = args.results_virusBLAST
species_demarcation = args.species_demarcation
RPM_threshold = args.RPM
evenness_threshold = args.evenness
counts = args.counts

#============================
# Global variables
#============================
total_number_or_reads = 0
set_of_viral_species = set()

dictionary_of_genera_by_species = dict()
dictionary_of_families_by_species = dict()
species_evalue_dictionary = dict()
species_pident_dictionary = dict()
species_histogram = dict()
species_unique_seq_count = dict()
species_segment_dictionary = dict()

path_to_files = os.path.dirname(os.path.abspath(summary_table))

#============================
# Output tables
#============================

table_of_viruses = list()
#============================
# Reading of summary table
#============================
fileObj = open(summary_table)
for line in fileObj:
	line = line.rstrip('\r\n')
	if "class" not in line:
		temp = line.split()
		total_number_or_reads += int(temp[1])

#============================
# Parsing of BLAST results
#============================

fileObj = open(results_virusBLAST)
for line in fileObj:
	line = line.rstrip('\r\n')
	split_by_tab = line.split("\t")	
	split_by_space = split_by_tab[1].split(" ")
	split_by_underscore = split_by_tab[0].split("_")	

	rank = int(split_by_underscore[0])
	counts = int(split_by_underscore[1])
	pident = float((split_by_tab[2]))
	evalue = float(split_by_tab[3])
	alignment_length = split_by_tab[4]
	genome_length = split_by_tab[5]
	sstart = split_by_tab[6]
	send = split_by_tab[7]
	average_position = (int(sstart)+int(send))/2 			
	relative_position = int(100*average_position/int(genome_length))

	species = split_by_space[1].replace("Species:","")
	segment = split_by_space[2].replace("Segment:","")	
	if segment != "na":
		species = species+"("+segment+")"
	set_of_viral_species.add(species)

	genus = split_by_space[3].replace("Genus:","")
	family = split_by_space[4].replace("Family:","")

	if species not in species_histogram:
		species_histogram[species] = [0] * 100
		dictionary_of_genera_by_species[species] = genus
		dictionary_of_families_by_species[species] = family
		species_unique_seq_count[species] = 0
		species_evalue_dictionary[species] = list()
		species_pident_dictionary[species] = list()
		species_segment_dictionary[species] = str()

	species_histogram[species][relative_position] += counts
	species_unique_seq_count[species] += 1
	species_evalue_dictionary[species].append(evalue)
	species_pident_dictionary[species].append(pident)
	species_segment_dictionary[species] = segment

fileObj.close()

#============================
# Identification of
# known viruses
#============================

known_viral_species_set = set()
identified_viruses_dictionary = dict()
identified_viruses_RPM_dictionary = dict()

for species in set_of_viral_species:
	genus = dictionary_of_genera_by_species[species]
	family = dictionary_of_families_by_species[species]
	count = sum(species_histogram[species])
	distribution_diversity = diversity(species_histogram[species])
	distribution_evenness = evenness(species_histogram[species])
	residuals = sum_of_residuals(species_histogram[species])[0]
	sqrt_squared_residuals = sum_of_residuals(species_histogram[species])[1]
	RPM = round(1000000*count/total_number_or_reads,1)

	median_evalue = '{:0.1e}'.format(
		median(species_evalue_dictionary[species])
		)
	mean_pident = round(mean(species_pident_dictionary[species]),1)

	if (distribution_evenness >= evenness_threshold  
		and mean_pident >= species_demarcation 
		and RPM >= RPM_threshold):

		known_viral_species_set.add(species)

		dictionary_entry = (str(RPM)
			+"\t"+species 
			+"\t"+genus
			+"\t"+family			
			+"\t"+str(count) 
			+"\t"+str(species_unique_seq_count[species])
			+"\t"+str(median_evalue)
			+"\t"+str(mean_pident)
			+"\t"+str(distribution_diversity)
			+"\t"+str(distribution_evenness) 
			+"\t"+str(residuals) 
			+"\t"+str(sqrt_squared_residuals))

		identified_viruses_dictionary[species] = dictionary_entry
		identified_viruses_RPM_dictionary[species] = RPM


#============================
# Identification of  
# distant viruses (genera
#============================	
putative_virus_histogram = dict()
putative_virus_unique_seq_count = dict()
putative_virus_evalue_dictionary = dict()
putative_virus_pident_dictionary = dict()
putative_virus_genus_dictionary = dict()
putative_virus_family_dictionary = dict()
species_to_putative_viruses_dictionary = dict()

set_of_putative_viruses = set()

set_of_putative_viruses_TP = set()
	
for species in set_of_viral_species:

	genus = dictionary_of_genera_by_species[species]
	family = dictionary_of_families_by_species[species]

	if species not in known_viral_species_set:
		putative_species = "putative_"+genus
		putative_species += "("+species_segment_dictionary[species]+")"
		putative_species = putative_species.replace("(na)","")
		set_of_putative_viruses.add(putative_species)
		putative_virus_genus_dictionary[putative_species] = genus
		putative_virus_family_dictionary[putative_species] = family
		species_to_putative_viruses_dictionary[species] = putative_species
		 

#		print(putative_species,species, genus, family, species_segment_dictionary[species])

		if putative_species not in putative_virus_histogram:
			putative_virus_histogram[putative_species] = [0] * 100

		for i in range (0,100):
			putative_virus_histogram[putative_species][i] += species_histogram[species][i]

for putative_virus in set_of_putative_viruses:

	genus = putative_virus_genus_dictionary[putative_virus]
	family = putative_virus_family_dictionary[putative_virus]
	distribution_diversity = diversity(putative_virus_histogram[putative_virus])
	distribution_evenness = evenness(putative_virus_histogram[putative_virus])
	residuals = sum_of_residuals(putative_virus_histogram[putative_virus])[0]
	sqrt_squared_residuals = sum_of_residuals(putative_virus_histogram[putative_virus])[1]
	count = sum(putative_virus_histogram[putative_virus])
	RPM = round(1000000*count/total_number_or_reads,1)


	if (distribution_evenness >= evenness_threshold  
		and genus != "nd" 
		and RPM >= RPM_threshold):

		dictionary_entry =(
			str(RPM)
			+"\t"+putative_virus 
			+"\t"+genus
			+"\t"+family			
			+"\t"+str(count) 
			+"\t"+str(species_unique_seq_count[species])
			+"\t"+str(median_evalue)
			+"\t"+str(mean_pident)
			+"\t"+str(distribution_diversity)
			+"\t"+str(distribution_evenness) 
			+"\t"+str(residuals) 
			+"\t"+str(sqrt_squared_residuals))

		identified_viruses_dictionary[putative_virus] = dictionary_entry
		identified_viruses_RPM_dictionary[putative_virus] = RPM
		set_of_putative_viruses_TP.add(putative_virus)


#	print(RPM, virus,distribution_diversity,distribution_evenness,residuals,sqrt_squared_residuals,count)

for each in table_of_viruses:
	print(each)

#============================
# Saving table of identified 
# viral species
#============================
table_of_identified_viruses = list()

print ("\n=== Detected viruses ===\n")

table_of_identified_viruses.append("RPM\tspecies\tgenus"\
	+"\tfamily\ttotal_counts\tunique_sequences"\
	+"\tevalue\tpident"\
	+"\tdiversity\tevenness\tresiduals\tstdv_residuals")

for virus, value in sorted(
	identified_viruses_RPM_dictionary.items(), 
	key = lambda item: item[1],	
	reverse = True):
#		print (identified_viruses_dictionary[virus])
		table_of_identified_viruses.append(identified_viruses_dictionary[virus])

virusTable_name = os.path.basename(summary_table)
virusTable_name = virusTable_name.replace("SummaryTable", "virusTable")
virusTable = os.path.join(path_to_files,
	virusTable_name)
with open(virusTable, 'w') as file_handler:
	for item in table_of_identified_viruses:
		file_handler.write("{}\n".format(item))

for line in table_of_identified_viruses:
	print(line)


#============================
# Saving table of counts
#============================
mapping_table = list()
mapping_table.append("Rank\tSpecies\tGenus\tFamily\tIsolate\tHost\tCountry\
\tPubmed\tPident\tEvalue\tPosition\tRelative_Position") 


fileObj = open(results_virusBLAST)
for line in fileObj:
	line = line.rstrip('\r\n')
	split_by_tab = line.split("\t")	
	split_by_space = split_by_tab[1].split(" ")
	split_by_underscore = split_by_tab[0].split("_")	

	rank = int(split_by_underscore[0])
	counts = int(split_by_underscore[1])
	pident = float((split_by_tab[2]))
	evalue = float(split_by_tab[3])
	alignment_length = split_by_tab[4]
	genome_length = split_by_tab[5]
	sstart = split_by_tab[6]
	send = split_by_tab[7]
	average_position = (int(sstart)+int(send))/2 			
	relative_position = round(100*average_position/int(genome_length),2)

	species = split_by_space[1].replace("Species:","")
	segment = split_by_space[2].replace("Segment:","")	
	if segment != "na":
		species = species+"("+segment+")"
	set_of_viral_species.add(species)

	genus = split_by_space[3].replace("Genus:","")
	family = split_by_space[4].replace("Family:","")

	isolate = split_by_space[5].replace("Isolate:","")
	host = split_by_space[6].replace("Host:","")
	country = split_by_space[7].replace("Country:","")
	pubmed = split_by_space[8].replace("Pubmed:","")

	if species in known_viral_species_set:
		mapping_entry = (
			str(rank),
			species,
			genus,
			family,
			isolate,
			host,
			country,
			pubmed,
			str(pident),
			str(evalue),
			str(average_position),
			str(relative_position)
			)
#		print (line)
#		print(mapping_entry)
		mapping_table.append("\t".join(mapping_entry))

	elif species_to_putative_viruses_dictionary[species] in set_of_putative_viruses_TP:
		mapping_entry = (
			str(rank),
			species_to_putative_viruses_dictionary[species],
			genus,
			family,
			isolate,
			host,
			country,
			pubmed,
			str(pident),
			str(evalue),
			str(average_position),
			str(relative_position)
			)
#		print(line)
#		print(mapping_entry)
		mapping_table.append("\t".join(mapping_entry))
# 	else:
# 		print(species_to_putative_viruses_dictionary[species])

# #	elif species_to_putative_viruses_dictionary[species] in set_of_putative_viruses_TP:

# for each in species_to_putative_viruses_dictionary:
# 	print(each, species_to_putative_viruses_dictionary[each])

virusMappingTable_name = os.path.basename(summary_table)
virusMappingTable_name = virusMappingTable_name.replace("SummaryTable", "virusMappingTable")
virusMappingTable = os.path.join(path_to_files,
	virusMappingTable_name)

with open(virusMappingTable, 'w') as file_handler:
	for item in mapping_table:
		file_handler.write("{}\n".format(item))		


fileObj.close()

#============================
# End of script
#============================


